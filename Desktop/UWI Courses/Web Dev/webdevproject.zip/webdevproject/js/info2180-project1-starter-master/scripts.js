window.addEventListener("load", (event) => {
  const form = document.querySelector("form");
  const message = document.querySelector(".message");

  form.addEventListener("submit", function (e) {
    e.preventDefault();

    // Get email address from the input field
    const emailInput = document.getElementById("email");
    // Remove leading and trailing spaces
    const emailAddress = emailInput.value.trim();

    // Check that email address is valid
    if (emailAddress !== "") {
      message.textContent = `Thank you! Your email address ${emailAddress} has been added to our mailing list!`;

      emailInput.value = "";
    } else {
      message.textContent = "Please enter a valid email address.";
    }
  });
});
